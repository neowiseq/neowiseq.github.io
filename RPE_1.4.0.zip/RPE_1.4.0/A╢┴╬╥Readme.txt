1.窗口过大 
打开"Settings.txt"，减小"WindowSize: "后的数值，保存并重新启动程序

2.切换语言为中文
打开"Settings.txt"，将"Language: "后的内容改为"zh.txt"，保存并重新启动程序

3.添加谱面闪退
可能是PhiEdit.exe所在的路径中有中文，可以移到D盘根目录等位置

4.请安装 /Resources/fonts 下的字体


1. The window is too big 
Open "Settings.txt", reduce the value after "WindowSize:", save and restart the program.

2.Switch language to English
Open "Settings.txt", change the content after "Language:" to "en.txt", save and restart the program.

3. Flashback when adding a chart
It may be that the path of PhiEdit.exe includes non-english characters, you can move to the root directory of D disk or other locations

4.Please install fonts under /Resources/fonts